#include "queue.h"

// Creates and initializes a new empty queue
Queue* q_create() {
    Queue* q = (Queue*)malloc(sizeof(Queue));
    if (q == NULL) {
        return NULL;
    }
    q->head = NULL;
    q->tail = NULL;
    return q;
}

// Adds item to the end of the queue
void q_add(Queue* q, char* data) {
    if (q == NULL) {
        return;
    }
    
    // Allocate memory for new node
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        return;
    }
    
    // Allocate memory for the data and copy it
    new_node->data = (char*)malloc(strlen(data) + 1);
    if (new_node->data == NULL) {
        free(new_node);
        return;
    }
    strcpy(new_node->data, data);
    new_node->next = NULL;
    
    // Add node to the queue
    if (q->tail == NULL) {
        // Queue is empty
        q->head = new_node;
        q->tail = new_node;
    } else {
        // Queue has elements
        q->tail->next = new_node;
        q->tail = new_node;
    }
}

// Removes the head of the queue, returning its contents
// Returns NULL if the queue is empty
char* q_next(Queue* q) {
    if (q == NULL || q->head == NULL) {
        return NULL;
    }
    
    // Get the head node
    Node* old_head = q->head;
    char* data = old_head->data;
    
    // Move head to next node
    q->head = old_head->next;
    
    // If queue is now empty, update tail
    if (q->head == NULL) {
        q->tail = NULL;
    }
    
    // Free the old node (but not the data, which we're returning)
    free(old_head);
    
    return data;
}

